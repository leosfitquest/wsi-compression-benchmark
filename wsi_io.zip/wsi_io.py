############################################################################
#                  Copyright (C) 1996-2023 Barco, NV.                      #
#      This software and the associated documentation are confidential     #
#                 and proprietary to Barco, NV.                            #
############################################################################

"""
Version 2025-11-14 | ETRO | Tien
- Added method to get stripe at specific magnification
Version 2026-06-10 | ETRO | Tien
- Modified get_stripe_at_magnification function to take into account real mag and nominal mag
Version 2026-07-15 | ETRO | Tien
- Added support for Hamamatsu in get_stripe_at_magnification


"""
from __future__ import annotations

import contextlib
import logging
import math
import types
from enum import Enum, auto, unique
from pathlib import Path
from typing import ClassVar

import numpy as np
import numpy as xp

from openslide import OpenSlide
from scipy import ndimage



@unique
class ScannerType(Enum):
    UNKNOWN = auto()
    LEICA_AT2 = auto()
    HAMAMATSU_XR = auto()        # NanoZoomer-XR (C12000 series)
    P150 = auto()                # 3DHistech Pannoramic SCAN 150
    P1000_UBE = auto()           # 3DHistech Pannoramic 1000
    LEICA_GT450_DX = auto()
    LEICA_SCANSCOPE_XT = auto()
    LEICA_UNKNOWN = auto()
    ARGOS = auto()
    LEICA_GT450 = auto()
    HAMAMATSU_NANOZOOMER_S20MD = auto()
    HAMAMATSU_NANOZOOMER_S60 = auto()
    HAMAMATSU_NANOZOOMER_S360 = auto()
    HAMAMATSU_NANOZOOMER_S360MD = auto()
    LEICA_GT400 = auto()
    LEICA_GT400_DX = auto()
    LEICA_GT050 = auto()
    LEICA_GT050_DX = auto()


def isLeica(scanner_type: ScannerType) -> bool:
    return 'LEICA' in scanner_type.name

def isHamamatsu(scanner_type: ScannerType) -> bool:
    return 'HAMAMATSU' in scanner_type.name

def is3DHistech(scanner_type: ScannerType) -> bool:
    return scanner_type in [ScannerType.P150, ScannerType.P1000_UBE]

def isArgos(scanner_type: ScannerType) -> bool:
    return scanner_type == ScannerType.ARGOS


class WsiIo:
    """
    Read WSI slides using OpenSlide backend only
    Simplified version containing only functionality for read_region_at_magnification and read_slide_generator
    No ICC profile support, single worker only (no multiprocessing)
    """

    DEFAULTS: ClassVar[dict[str: float]] = {'mpp_tol': 0.1}

    def __init__(self, slide_path: Path | str):
        self.slide_path = Path(slide_path)

    def __enter__(self):
        self._load_slide()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self):
        self.slide.close()

    def _load_slide(self):
        logging.debug(f'Loading slide {str(self.slide_path)} using OpenSlide backend')
        self.slide = OpenSlide(str(self.slide_path))
        self.meta_data = self.slide.properties
        with contextlib.suppress(KeyError):
            self.tile_size = int(self.meta_data['openslide.level[0].tile-width'])

    @property
    def mpp(self):
        return float(self.meta_data['openslide.mpp-x'])

    @property
    def magnification(self):
        return WsiIo.mpp_to_magnification(self.mpp)

    @staticmethod
    def magnification_to_mpp(magnification):
        return 10 / magnification

    @staticmethod
    def mpp_to_magnification(mpp):
        return 10 / mpp
    
    def get_stripe_at_magnification(self, magnification) -> int:
        vendor = self.meta_data.get('openslide.vendor', '').lower()        
        base_mag = self.magnification
        nominal_mag = 40
        print(f"Vendor: {vendor} | Base mag: {base_mag} | Nominal mag: {nominal_mag}")
        
        ratio = base_mag / nominal_mag
        stripe_lvl0 = None
        if vendor == 'aperio':
            stripe_lvl0 = self.meta_data.get('aperio.StripeWidth')
            if stripe_lvl0 is None:
                return None

        elif vendor == 'mirax':
            stripe_lvl0 = self.meta_data.get('mirax.NONHIERLAYER_2_LEVEL_0_SECTION.COMPRESSSED_STITCHING_ORIG_CAMERA_TILE_WIDTH')
            if stripe_lvl0 is None:
                return None
            
        elif vendor == 'hamamatsu':
            stripe_lvl0 = self.meta_data.get('openslide.level[0].tile-width')
            if stripe_lvl0 is None:
                return None
            
        else:
            print(f"Vendor {vendor} is not yet supported")
            return None
        
        value = float(stripe_lvl0) * (magnification / nominal_mag) * ratio
        return int(round(value))

    def get_level_count(self) -> int:
        return int(self.meta_data['openslide.level-count'])

    def get_level_dimensions(self, level: int | None = None) -> list[list[int]] | list[int]:
        dimensions = self.slide.level_dimensions
        return dimensions if level is None else dimensions[level]

    def get_level_downsamples(self) -> list[float]:
        return self.slide.level_downsamples

    def read_region(
            self,
            location: tuple[int, int] | list[tuple[int, int]] | list[list[int]] = (0, 0),
            level: int | None = None,
            size: tuple[int, int] | None = None,
            as_xp_array: bool = True,
            force_cpu: bool = False,
            downsample_factor: float | None = None,
            skip_alpha_removal: bool = False,
            **kwargs) -> np.ndarray:
        """
        Read a sub-resolution image using OpenSlide backend
        See https://openslide.org/api/python/#openslide.OpenSlide.read_region for more information on read_region API for OpenSlide backend
        @param as_xp_array: Converts the resulting region to a NumPy or CuPy array when set.
        """
        assert as_xp_array, "Deprecated setting: as_xp_array must always be set to True (why would you want read_region to return a PIL Image or cucim CuImage object?)"

        if isinstance(location, (list, tuple)) and len(location) == 0:  # noqa: UP038
            return iter([])
        ndim = np.array(location).ndim
        assert ndim in [1, 2]
        make_generator = ndim == 2  # noqa: PLR2004

        logging.info(f"Single worker mode, use generator: {make_generator}")

        def __process_region(region, downsample_factor, as_xp_array, skip_alpha_removal, force_cpu):
            return WsiIo._scale(
                    WsiIo._remove_alpha(
                        WsiIo._as_xp_array(
                            region,  # This may be a single region or a batch of regions
                            as_xp_array,
                            force_cpu),
                    as_xp_array,
                    skip_alpha_removal),
                downsample_factor,
                force_cpu)

        size = self.get_level_dimensions(0 if level is None else level) if size is None else size

        def __read_region(loc, level, size, **kwargs):
            region = np.asarray(
                self.slide.read_region(loc, level, size, **kwargs),
                dtype=np.uint8).reshape([size[1], size[0], 4])
            return region

        def __process_region_os(loc, level, size, downsample_factor, as_xp_array, skip_alpha_removal, force_cpu, **kwargs):
            region = __read_region(loc, level, size, **kwargs)
            return __process_region(region, downsample_factor, as_xp_array, skip_alpha_removal, force_cpu)

        if make_generator:
            def __gen():
                for loc in location:
                    yield __process_region_os(loc, level, size, downsample_factor, as_xp_array, skip_alpha_removal, force_cpu, **kwargs)
            return __gen()
        else:
            return __process_region_os(location, level, size, downsample_factor, as_xp_array, skip_alpha_removal, force_cpu, **kwargs)

    def read_slide_generator(
            self,
            tile_size: int | list[int],
            level: int | None = None,
            magnification: float | None = None,
            mpp_tol: float = DEFAULTS['mpp_tol'],
            bbox: list[int] | None = None,
            only_complete_patches: bool = True,
            overlapping_patches: bool = False,
            overlap_size: int | None = None,
            skip_alpha_removal: bool = False,
            force_cpu: bool = False,
            **kwargs) -> tuple[tuple[types.GeneratorType, int, int], list[list[int]]]:
        """
        Retrieve a generator to read a region of a slide at a predefined tile_size and at a predefined magnification or level.

        @param tile_size: size of the tiles for which start locations should be generated
                          when `tile_size` is an integer, square tiles will be generated
                          when `tile_size` is a list of integers, rectangular tiles will be generated ([width, height])
        @param level: level at which the image data is read.
                      When not specified, the optimal level for reading a slide at the specified magnification is first determined (see `get_level_for_mpp`).
        @param magnification: magnification at which the slide should be read
                              hen not specified, the slide is read at the specified pyramid level.
        @param mpp_tol: see `get_level_for_mpp`.
        @param bbox: optional ROI region in which patch locations should be generated, otherwise use the entire slide
        @param only_complete_patches: Don't read tiles which are not entirely inside the slide or bbox. Defaults to True.
        @param overlapping_patches: Overlap tiles when slide resolution or bbox resolution is not a multiple of the tile size. Defaults to False.
                                    This way the first and last patches (both horizontally and vertically) align with the slide (or bbox ROI when specified) edge.
        @param overlap_size: when set to a positive value, patches are generated in `only_complete_patches` mode, but with an increment reduced by `overlap_size`

        @return generator to read region of a slide at predefined tile size and level OR magnification, also returns locations where patches are read from
        """
        assert (level is None) ^ (magnification is None)

        if isinstance(tile_size, int):
            tile_size = (tile_size, tile_size)
        elif type(tile_size) is not tuple:
            tile_size = tuple(tile_size)

        if level is None:  # Determine optimal level and tile size for requested magnification
            level, downsample_factor, tile_size_read, _ = self.get_info_for_magnification(tile_size, magnification, mpp_tol)
            logging.info(f"reading slide at magnification {magnification} using level {level}, tile size {tile_size_read} and "
                         f"down sample factor {downsample_factor:.4f} to obtain a tile size of {tile_size}")
        else:
            tile_size_read = tile_size
            downsample_factor = 1
            logging.info(f"reading slide at level {level} and tile size {tile_size}")

        overlap_size_level_0 = self.get_overlap_size_level_0(overlap_size, downsample_factor, level)
        locations, x_n, y_n  = self.get_locations(
            tile_size=tile_size_read, level=level, bbox=bbox,
            only_complete_patches=only_complete_patches, overlapping_patches=overlapping_patches,
            overlap_size_level_0=overlap_size_level_0)
        locations = np.array(locations).astype(np.int32).tolist()
        logging.info(f'Number of patches to process: {len(locations)}, scaling: {magnification is not None}')

        generator = self.read_region(
                location=locations,
                level=level,
                size=tile_size if magnification is None else tile_size_read,
                as_xp_array=True,
                force_cpu=force_cpu,
                downsample_factor=downsample_factor,
                skip_alpha_removal=skip_alpha_removal,
                **kwargs)
        return generator, locations, x_n, y_n

    def read_region_at_magnification(self, magnification: float, location=(0, 0), size=None, bbox=None, force_cpu: bool = False,
                                     mpp_tol: float = DEFAULTS['mpp_tol'], extended_info: bool = False, **kwargs):
        """
        Read region at specified magnification. This region is specified using level 0 based location and size coordinates.
        @param magnification: magnification at which the region should be read
        @param location: level 0 based region upper left location coordinates (x, y), defaults to the origin
        @param size: level 0 based region width and height (w, h), defaults to the entire slide
        @param force_cpu: Force using CPU when set to True
        @param mpp_tol: see `get_level_for_mpp`.
        """
        level, downsample_factor, _, _ = self.get_info_for_magnification(None, magnification, mpp_tol=mpp_tol)
        level_downsample = self.get_level_downsamples()[level]
        if size is None:
            assert location == (0, 0)
            y_start, x_start, y_stop, x_stop = self.get_bbox(bbox)  # Reads entire slide if bbox is None
            location = (x_start, y_start)  # Updated with potential .mrxs xy-offset
            size = (x_stop - x_start, y_stop - y_start)
        size_downsample = [int(x // level_downsample) for x in size]

        region = self.read_region(location=location, level=level, size=size_downsample, as_xp_array=True, downsample_factor=downsample_factor, force_cpu=force_cpu, **kwargs)

        if extended_info:
            # level dimenstions and image shape are stored in a different order
            assert size[0] == x_stop - x_start, f"Actual magnification not yet upported when not reading the entire slide"
            y_start, x_start, y_stop, x_stop = self.get_bbox(bbox)  # Reads entire slide if bbox is None
            actual_magnification = self.magnification * (region.shape[0] / (y_stop - y_start) + region.shape[1] / (x_stop - x_start)) / 2
            return region, actual_magnification
        else:
            return region

    @staticmethod
    def _scale(batch_of_patches, downsample_factor, force_cpu):
        if downsample_factor is None:
            return batch_of_patches

        img_rank = len(batch_of_patches.shape)
        if img_rank == 4:  # noqa: PLR2004
            zoom = [1, 1 / downsample_factor, 1 / downsample_factor, 1]
        elif img_rank == 3:  # noqa: PLR2004
            zoom = [1 / downsample_factor, 1 / downsample_factor, 1]
        else:
            msg = f'Rank of batch_of_patches={img_rank} not supported. Exptected 3 or 4.'
            raise NotImplementedError(msg)
        scaled = ndimage.zoom(
            batch_of_patches,
            zoom=zoom,
            order=1,
            mode='reflect'
        )
        return scaled

    @staticmethod
    def _as_xp_array(array, as_xp_array, force_cpu):
        if as_xp_array:
            if force_cpu:
                if f"{array.__class__.__module__}.{array.__class__.__name__}" == "cupy.ndarray":
                    xp_array = array.get()
                else:
                    xp_array = np.asarray(array)
            else:
                xp_array = xp.asarray(array)
            return xp_array

        return array

    @staticmethod
    def _remove_alpha(xp_array, as_xp_array, skip_alpha_removal=False):
        if not skip_alpha_removal and as_xp_array and xp_array.shape[-1] > 3:  # noqa: PLR2004
            return xp_array[..., :3]
        return xp_array

    def get_locations(
            self,
            tile_size: int | list[int],
            level: int | None = 0,
            bbox: tuple[int] | None = None,
            only_complete_patches: bool = True,
            overlapping_patches: bool = False,
            overlap_size_level_0: float | None = None) -> tuple[list[list[int]], int, int]:
        """
        Generate a list of patch start locations for patches, assuming each patch has a `tile_size'.
        Also return the number of horizontal and vertical patches.
        @param tile_size: size of the tiles for which start locations should be generated
                          when `tile_size` is an integer, square tiles will be generated
                          when `tile_size` is a list of integers, rectangular tiles will be generated ([width, height])
        @param level: level at which the image data is read.
                      When not specified, the optimal level for reading a slide at the specified magnification is first determined (see `get_level_for_mpp`).
        @param magnification: magnification at which the slide should be read
                              when not specified, the slide is read at the specified pyramid level.
        @param bbox: optional ROI region in which patch locations should be generated, otherwise use the entire slide
        @param only_complete_patches: Don't read tiles which are not entirely inside the slide or bbox. Defaults to True.
        @param overlapping_patches: Overlap tiles when slide resolution or bbox resolution is not a multiple of the tile size. Defaults to False.
                                    This way the first and last patches (both horizontally and vertically) align with the slide (or bbox ROI when specified) edge.
        @param overlap_size_level_0: when set to a positive value, patches are generated in `only_complete_patches` mode,
                                     but with an increment reduced by `overlap_size_level_0`
        """
        ys, xs = self.__get_yx_coordinates(tile_size, level, bbox, only_complete_patches, overlapping_patches, overlap_size_level_0)

        locations = [[x, y] for y in ys for x in xs]
        x_n = len(xs)
        y_n = len(ys)
        return locations, x_n, y_n

    def get_level_for_mpp(self, mpp=0.25, mpp_tol: float = DEFAULTS['mpp_tol']):
        """
        Retrieve the optimal level to read a slide at a given MPP.
        The chosen level is as such that the image can be downsampled to match the required MPP with the lowest possible downsample factor.
        @param mpp: micro-meter per pixel. Defaults to 0.25 (= 40x magnification).
        @param mpp_tol: if MPP is within the specified relative tolerance matching a given level,
                        return that level, even if it would require upsampling. Defaults to 10%.
        @return optimal level for reading slide at a given MPP
        """
        level_downsamples = self.get_level_downsamples()
        level_count = self.get_level_count()
        mpp_per_level = [self.mpp * level_downsamples[level] for level in range(level_count)]
        for level in range(level_count - 1):
            if mpp_per_level[level + 1] > mpp / (1 - mpp_tol):
                return level
        return level_count - 1

    def get_downsample_for_mpp(self, mpp=0.25, level=None, mpp_tol: float = DEFAULTS['mpp_tol']):
        """
        Calculate the needed downsample factor to obtain an image at the specified micro-meter per pixels when reading from the specified level.
        @param mpp: micro-meter per pixel. Defaults to 0.25 (= 40x magnification).
        @param level: level at which the image data is read. Defaults to None.
                      When not specified, the optimal level for reading a slide at the specified MPP is first determined (see `get_level_for_mpp`).
        @param mpp_tol: see `get_level_for_mpp`.
        @return downsample factor needed to rescale tiles read at the resolved level to match the specified MPP
        """
        if level is None:
            level = self.get_level_for_mpp(mpp, mpp_tol)
        level_0_mpp = self.mpp
        level_downsample = self.get_level_downsamples()[level]
        return mpp / (level_0_mpp * level_downsample)

    def get_level_for_magnification(self, magnification=40, mpp_tol: float = DEFAULTS['mpp_tol']):
        """
        Retrieve the optimal level to read a slide at a given magnification.
        @param magnification: requested slide magnification setting, defaults to 40x (= 0.25 MPP)
        @param mpp_tol: see `get_level_for_mpp`.
        @return optimal level for reading slide at a given magnification
        """
        return self.get_level_for_mpp(WsiIo.magnification_to_mpp(magnification), mpp_tol)

    def get_downsample_for_magnification(self, magnification=40, level=None, mpp_tol: float = DEFAULTS['mpp_tol']):
        """
        Calculate the needed downsample factor to obtain an image at the specified magnification when reading from the specified level.
        @param magnification: requested slide magnification setting, defaults to 40x (= 0.25 MPP)
        @param level: level at which the image data is read.
                      When not specified, the optimal level for reading a slide at the specified magnification is first determined (see `get_level_for_mpp`).
        @param mpp_tol: see `get_level_for_mpp`.
        @return downsample factor needed to rescale tiles read at the resolved level to match the specified magnification
        """
        return self.get_downsample_for_mpp(WsiIo.magnification_to_mpp(magnification), level=level, mpp_tol=mpp_tol)

    def get_overlap_size_level_0(self, overlap_size, downsample_factor, level):
        if overlap_size is None:
            return None
        else:
            return overlap_size * downsample_factor * self.get_level_downsamples()[level]

    def get_info_for_magnification(self, tile_size, magnification, mpp_tol: float = DEFAULTS['mpp_tol'], overlap_size: int = 0, ai_is_image_to_image: bool = True):
        """
        @param tile_size: size of the tiles for which start locations should be generated (read_region OUTPUT tile size)
                          when `tile_size` is an integer, square tiles will be generated
                          when `tile_size` is a list of integers, rectangular tiles will be generated ([width, height])
        @param magnification: magnification at which the slide should be read
                              when not specified, the slide is read at the specified pyramid level.
        @param overlap_size: Overlap size used when stiching the read_region output tiles (which is typically the AI model input domain).
        @param ai_is_image_to_image: resulting magnification is calculated assuming the upstream AI is an image to image AI (potentially created using overlapping tiles)
                                     when True, or assuming an output map with a single pixel per AI input tile when False
        """
        level = self.get_level_for_magnification(magnification, mpp_tol=mpp_tol)

        # We read bigger tiles and will later-on downsample these
        downsample_factor = self.get_downsample_for_magnification(magnification, level=level, mpp_tol=mpp_tol)

        if tile_size is None:
            return level, downsample_factor, None, magnification

        # Retrieve the tile size as single integer, this assumes tiles are square in case tile_size was provided as a list !
        tile_size_int = tile_size if isinstance(tile_size, int) else tile_size[0]

        # Quantize the downsample factor to match the actual tile_size and tile_size_read ratio
        tile_size_read = int(round(tile_size_int * downsample_factor))
        downsample_factor_quantized = tile_size_read / tile_size_int

        # Calculate the final magnification
        overlap_size_level_0 = self.get_overlap_size_level_0(overlap_size, downsample_factor_quantized, level)
        increment_level_0, _ = self.__get_increment_level_0(level, tile_size_read, overlap_size_level_0)
        if ai_is_image_to_image:
            # The AI model input w/h is tile_size_int, the output image propagates with crops of size tile_size_int - overlap_size
            increment_output_image = tile_size_int - (0 if overlap_size is None else overlap_size)
        else:
            # The AI model input w/h is tile_size_int, the output image propagates with a single pixel
            increment_output_image = 1
        actual_magnification = self.magnification * increment_output_image / increment_level_0

        if not isinstance(tile_size, int):
            tile_size_read = (tile_size_read, tile_size_read)

        # level: the level to be used by read_region to read tiles from
        # tile_size_read: the size of the tiles to be read by read_region at the specified level
        # downsample_factor_quantized: factor by which the tiles read from read_region (of size tile_size_read^2) must
        #                              be downsampled to finally obtain tiles with size tile_size_int^2
        # actual_magnification: the final magnification of the output image, taking into account all quantisations as
        #                       well as the stitching of output tiles into the output image, accounting for a potential overlap
        return level, downsample_factor_quantized, tile_size_read, actual_magnification

    def get_bbox(self, bbox=None):
        """
        Retrieve the bounding box matching the scanned area.
        For now it is not supported to define both a custom bbox as well as use the mrxs scanned area bounding box.
        """
        level_0_dimensions = self.get_level_dimensions(level=0)  # order: x, y

        if self.slide_path.suffix == '.mrxs':
            location = (int(self.meta_data['openslide.bounds-x']), int(self.meta_data['openslide.bounds-y']))
            sizes    = [int(self.meta_data['openslide.bounds-width']), int(self.meta_data['openslide.bounds-height'])]
            x_start = location[0]
            y_start = location[1]
            x_stop = x_start + sizes[0]
            y_stop = y_start + sizes[1]
            if bbox is None:
                bbox = y_start, x_start, y_stop, x_stop
                logging.info(f"Using MRXS bounding box: y_start: {y_start}, x_start: {x_start}, y_stop: {y_stop}, x_stop: {x_stop}")
            else:
                # Take the smallest overlapping rectangle of both bbounding boxes
                logging.info(f"x_start {x_start}, y_start {y_start}, x_stop {x_stop}, y_stop {y_stop}, bbox {bbox}")
                y_start = max(y_start, bbox[0])
                x_start = max(x_start, bbox[1])
                y_stop = min(y_stop, bbox[2])
                x_stop = min(x_stop, bbox[3])
                assert x_start < x_stop and y_start < y_stop, \
                    f"Invalid final bounding box, behavior will be undefined... {[y_start, x_start, y_stop, x_stop]}"  # noqa: PT018
                bbox = y_start, x_start, y_stop, x_stop
                logging.info(f"Using combo of user defined and MRXS bounding box: y_start: {y_start}, x_start: {x_start}, y_stop: {y_stop}, x_stop: {x_stop}")
        elif bbox is not None:
            logging.info(f"Using user defined bounding box: y_start: {bbox[0]}, x_start: {bbox[1]}, y_stop: {bbox[2]}, x_stop: {bbox[3]}")
        else:
            bbox = 0, 0, level_0_dimensions[1], level_0_dimensions[0]
            logging.info(f"Using entire slide: y_start: {bbox[0]}, x_start: {bbox[1]}, y_stop: {bbox[2]}, x_stop: {bbox[3]}")

        # Clip bbox to slide level 0 dimensions
        y_start, x_start, y_stop, x_stop = bbox
        y_start = min(level_0_dimensions[1], max(0, y_start))
        x_start = min(level_0_dimensions[0], max(0, x_start))
        y_stop  = min(level_0_dimensions[1], max(0, y_stop ))
        x_stop  = min(level_0_dimensions[0], max(0, x_stop ))
        bbox = y_start, x_start, y_stop, x_stop

        return bbox

    def __get_increment_level_0(self, level, tile_size: int, overlap_size_level_0: float | None):
        """
        tile_size is based on the selected level, but locations are based on level 0
        Note: the overlap_size_level_0 input is not quantized!
        """
        overlap_size_level_0 = 0 if overlap_size_level_0 is None else overlap_size_level_0
        level_downsample = self.get_level_downsamples()[level]
        if isinstance(tile_size, int):
            tile_size_level_0 = tile_size * level_downsample
            increment_level_0_x = increment_level_0_y = int(round(tile_size_level_0 - overlap_size_level_0))
        else:
            tile_size_level_0 = [ts * level_downsample for ts in tile_size]
            increment_level_0_x, increment_level_0_y = (int(round(ts - overlap_size_level_0)) for ts in tile_size_level_0)
        return increment_level_0_x, increment_level_0_y

    def __get_yx_coordinates(self, tile_size: int, level: int, bbox: tuple, only_complete_patches:bool, overlapping_patches:bool,
                             overlap_size_level_0:float | None = None):
        assert sum([only_complete_patches, overlapping_patches, overlap_size_level_0 is not None]) <= 1, \
            "None or exactly one of 'only_complete_patches', 'overlapping_patches' or 'overlap_size is not None' must be True"

        y_start, x_start, y_stop, x_stop = self.get_bbox(bbox)

        # Tile size and overlap size is based on the current level, but locations are based on level 0
        increment_level_0_x, increment_level_0_y = self.__get_increment_level_0(level, tile_size, overlap_size_level_0)

        # Now work out the locations in level 0
        if overlap_size_level_0 is not None and overlap_size_level_0 > 0:
            # A grid of patches with a fixed overlap size, of which the center crop matches the upper left corner of the slide or bounding box.
            # If the last patch in a row / column doesn't fit the specified slide dimensions or bounding box, it is still included.
            xs = []
            ys = []
            x = int(round(x_start - overlap_size_level_0 / 2))
            while x < int(math.ceil(x_stop - overlap_size_level_0 / 2)) or len(xs) == 0:
                xs.append(x)
                x += increment_level_0_x
            xs = xs if len(xs) > 0 else [x_start]
            y = int(round(y_start - overlap_size_level_0 / 2))
            while y < int(math.ceil(y_stop - overlap_size_level_0 / 2)) or len(ys) == 0:
                ys.append(y)
                y += increment_level_0_y
            ys = ys if len(ys) > 0 else [y_start]
        elif overlapping_patches:
            # A grid of patches covering the slide, equidistantly spread accross the full widht / height.
            # With the first and last patches in a row / column aligning with the edge of the slide.
            x_n = max(1, 2 + math.ceil((x_stop - x_start - 2 * increment_level_0_x) / increment_level_0_x))
            x_inc = 0 if x_n == 1 else (x_stop - increment_level_0_x - x_start) / (x_n - 1)
            xs = [max(x_start, min(x_stop - increment_level_0_x, round(x_start + i * x_inc))) for i in range(x_n)]
            y_n = max(1, 2 + math.ceil((y_stop - y_start - 2 * increment_level_0_y) / increment_level_0_y))
            y_inc = 0 if y_n == 1 else (y_stop - increment_level_0_y - y_start) / (y_n - 1)
            ys = [max(y_start, min(y_stop - increment_level_0_y, round(y_start + i * y_inc))) for i in range(y_n)]
        else:
            # Only_complete_patches: False
            # > A grid of patches covering the entire slide and
            # > potentionally extending the slide at the right and bottom area
            # Only_complete_patches: True
            # > A grid of patches covering the slide, excluding the rightmost and lowermost columns/rows
            # > if the width / height is not a multiple of the tile siz
            if only_complete_patches and bbox is None:  # Complete patches as of bbox (0, 0) origin grid
                x_start = int(np.ceil(x_start / increment_level_0_x) * increment_level_0_x)
                y_start = int(np.ceil(y_start / increment_level_0_y) * increment_level_0_y)
                x_stop = int(np.floor(x_stop / increment_level_0_x) * increment_level_0_x)
                y_stop = int(np.floor(y_stop / increment_level_0_y) * increment_level_0_y)
            elif only_complete_patches:  # Complete patches as of bbox (x_start, y_start) origin grid
                x_stop = x_start + int(np.floor((x_stop - x_start) / increment_level_0_x) * increment_level_0_x)
                y_stop = y_start + int(np.floor((y_stop - y_start) / increment_level_0_y) * increment_level_0_y)
            xs = list(range(x_start, x_stop, increment_level_0_x))
            ys = list(range(y_start, y_stop, increment_level_0_y))

        return ys, xs
